import sys

from chirp.wxui import chirpmain

if __name__ == '__main__':
    sys.exit(chirpmain())
